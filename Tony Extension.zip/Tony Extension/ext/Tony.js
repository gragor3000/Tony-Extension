/*chrome.tabs.executeScript(null, {var win = window.open('http://www.twitch.tv/rsgloryandgold', '_blank');
win.focus();*/

window.open('http://www.twitch.tv/rsgloryandgold','_blank');